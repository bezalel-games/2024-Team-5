public interface IBreakable
{
    public void Break();
}
