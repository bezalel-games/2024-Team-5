using UnityEngine;

namespace Gal.Scripts
{
    public class AttachablesManager: MonoBehaviour
    {
        public LegObject rightLeg;
        public LegObject leftLeg;
    
    }
}
