using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spring : MonoBehaviour
{
    public bool canJump = true;
    public float speed = 5f;
    public float jumpForce = 10f;
}
