using UnityEngine;

namespace Gal.Scripts
{
    public class BodyPartObject : MonoBehaviour
    {
        public enum BodyType
        {
            Leg,Hand,Back
        }
    
        public BodyType bodyType;
    }
}

